/*
******************************
KSPP Demoset 2014 LCD 1602
******************************
*/

#include "stm32f3xx.h"

#define COMAND	    		(GPIOB->BSRRH |= GPIO_BSRR_BS_13); 
#define WRDATA	    		(GPIOB->BSRRL |= GPIO_BSRR_BS_13);


char A = 1;			// Yellow LED state
char B = 0;			// Contact �Bounce� Delay ON/OFF
char STATE = 0;	// State (0-Menu, 1-ADC1, 2-ADC2, 3-ADC3, 4-ADC-4, 5-DAC-A,  6- DAC-B, 7-Memory, 8-Info, 9-UID)
char SMENU = 0;	// Menu Selected Item
char VDACA = 0; // Value DHR(DOR) for DAC line 1
char VDACB = 0; // Value DHR(DOR) for DAC line 2


 void simpleDelay(unsigned int delayTime)
{
	for (unsigned int i=0; i < delayTime; i++);
}

void SEND (unsigned char SDAT	)			// Display Write Function with strobe
{	
GPIOD->ODR |= SDAT;									// WR DATA to ODR Registr Port D
	
simpleDelay(10);										
GPIOB->BSRRL |= GPIO_BSRR_BS_15;		// Generation STROB signal on PB15
simpleDelay(10);
GPIOB->BSRRH |= GPIO_BSRR_BS_15;	
simpleDelay(40);
	
GPIOD->ODR &= ~0xFF;								// Reset Data Bits (PD0...PD7)
}

char ConvertD ( unsigned int Zifra) 					// Convert Decimal 0-9 Number into WH0802A CODE
 {
		char DIG = 0x00;
	 
	  if (Zifra > 9) Zifra = 9;
	  if (Zifra < 1) Zifra = 0;
		if (Zifra == 0) DIG = 0x30;
		if (Zifra == 1) DIG = 0x31;
	 	if (Zifra == 2) DIG = 0x32;
	 	if (Zifra == 3) DIG = 0x33;
	 	if (Zifra == 4) DIG = 0x34;
	 	if (Zifra == 5) DIG = 0x35;
	 	if (Zifra == 6) DIG = 0x36;
	 	if (Zifra == 7) DIG = 0x37;
	 	if (Zifra == 8) DIG = 0x38;
	 	if (Zifra == 9) DIG = 0x39;
		
	 return DIG;
}
 
void DisplayStart()									// Display Initialization
{

	GPIOA->BSRRH |= GPIO_BSRR_BS_11; // Pre-Setup Write Only State
	
	simpleDelay(700000); 						// Display Start Time >20 ms
	COMAND; 												
	SEND(0x38) ; 										// Function Set: 8-bit, 2-line
	simpleDelay(1500);							// Wait >37 us
	SEND(0x0C) ; 										// Display Set (No Cursor & No Blinking)
	simpleDelay(1500);							// Wait >37 us
	SEND(0x6) ; 										// Entery Mode Set (Right-Moving Cursor)
	simpleDelay(1500);							// Wait >37 us
	SEND(0x1) ; 										// Display Clear
	simpleDelay(51000);							// Wait >1.53 ms
	
}

void WaitMsg()																// Print Starting Message
{
COMAND; 
SEND(0x80) ; // First Line
WRDATA;			 
	SEND(0x20); SEND(0x43); SEND(0xB9); SEND(0x65); SEND(0xB8); SEND(0xA2); SEND(0x20); SEND(0xB6); SEND(0x6F); SEND(0xB8); SEND(0xB9);
	SEND(0x70); SEND(0x6F); SEND(0xA6); SEND(0xB1); SEND(0x20);
COMAND; 
SEND(0xC0) ; // 2-nd line
WRDATA;
	SEND(0x20); SEND(0xB9); SEND(0x6F); SEND(0xAA); SEND(0xB8); SEND(0x6F); SEND(0x63); SEND(0xB9); SEND(0xA4); SEND(0x20); SEND(0x93);
	SEND(0x8F); SEND(0x4D); SEND(0x4F); SEND(0x43); SEND(0x20);

}

void EnteringMenu()
{
COMAND; 
SEND(0x1) ; 										// Display Clear
simpleDelay(51000);							// Wait >1.53 ms
WRDATA;			
SEND(0x42); SEND(0x8E); SEND(0x80); SEND(0x4F); SEND(0x50); SEND(0x20); SEND(0x50); SEND(0x45); SEND(0x83); SEND(0x84); SEND(0x4D); SEND(0x41);
	SEND(0x20); SEND(0x20); SEND(0x12); SEND(0x13);
}

void EnergoEngInfo()
{
COMAND; 
SEND(0x1) ; 										// Display Clear
simpleDelay(51000);							// Wait >1.53 ms
WRDATA;			
	SEND(0x8F); SEND(0x48); SEND(0x45); SEND(0x50); 
	SEND(0x81); SEND(0x4F); SEND(0x84); SEND(0x48); 
	SEND(0x83); SEND(0x84); SEND(0x48); SEND(0x84);
	SEND(0x50); SEND(0x84); SEND(0x48); SEND(0x81);
COMAND; 
SEND(0xC0) ; // 2-nd line
WRDATA;
	SEND(0x4E); SEND(0x30); SEND(0x30); SEND(0x31); 
	SEND(0x20); SEND(0x20); SEND(0x20); SEND(0x28); 
	SEND(0x43); SEND(0x29); SEND(0x20); SEND(0x32); 
	SEND(0x30); SEND(0x31); SEND(0x34);
	
}


void TIM1_UP_TIM16_IRQHandler (void)		// Timer TIM1 Update interrupt
{
	TIM1->SR &= ~TIM_SR_UIF;								// Clear Update interrupt flag
	
if (A == 1)
		{	
			A = 0;
			GPIOC->BSRRH |= GPIO_BSRR_BS_2;						// Onboard yellow LED - Off
		} else 
			{
				A=1;
				GPIOC->BSRRL |= GPIO_BSRR_BS_2;				// Onboard yellow LED - ON
			}
}

void TIM2_IRQHandler (void)
{
TIM2->SR &= ~TIM_SR_UIF;								// Clear Update interrupt flag

	
}


void TIM15_IRQHandler (void)
{
B=0;
}

int main (void)
{
/* ******* Periph clock Configuration ******* */
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN;		// Port A clock Enable 
	RCC->AHBENR |= RCC_AHBENR_GPIOBEN;		// Port B clock Enable 
	RCC->AHBENR |= RCC_AHBENR_GPIOCEN;		// Port C clock Enable 
	RCC->AHBENR |= RCC_AHBENR_GPIODEN;		// Port D clock Enable 
	RCC->AHBENR |= RCC_AHBENR_GPIOEEN;		// Port E clock Enable 
	
	RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;		// TIM1 timer clock enable
	
	RCC->APB2ENR |= RCC_APB2ENR_TIM15EN;	// TIM15 timer clock enable
	
	
	RCC->APB1ENR |= RCC_APB1ENR_DAC1EN;		// DAC1 clock Enable
	
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
	TIM2->PSC = 84000;
	TIM2->ARR = 10000;
	TIM1->EGR |= TIM_EGR_UG;							// Update TIM1 Registers
	TIM2->DIER |= TIM_DIER_UIE;		
NVIC_EnableIRQ (TIM2_IRQn);
	
/* ********* Ports Configuration ******** */
	

	GPIOA->MODER |= 0x1410700;						// PA4 - DAC_Out, PA5, PA8, PA11, PA12 - GP output mode
	GPIOA->PUPDR |= 0x2AAA8AA;						// PortA - Pull-down, PA4 - no;
	
	GPIOB->MODER |= 0x44000000;						// PB13, PB15  GP output mode
	GPIOB->PUPDR |= 0xAAAA582A;						// PortB - Pull-down, PB6, PB7  pull-UP mode
	
	GPIOC->MODER |= 0x00000054;						// PC1...PC3 GP output mode
	GPIOC->PUPDR |= 0x15AAAAA;						// PortC - Pull-down, PC10, PC11, PC12 - Pull-up mode
	
	GPIOD->MODER |= 0x5555;								// PD0...PD7 - GP output mode
	GPIOD->PUPDR |= 0xAAAA;								// PD0...PD7 - Pull-down mode				
	
	
/* *************************************** */
	
	TIM1->PSC = 31999;										// Prescaller value
	TIM1->ARR = 150;											// Auto-Reload value = Period
	TIM1->EGR |= TIM_EGR_UG;							// Update TIM1 Registers
	TIM1->DIER |= TIM_DIER_UIE;						// Update interrupt enable
	
	
	TIM15->PSC = 31999;										// Prescaller value
	TIM15->ARR = 10;											// Auto-Reload value = Period
	TIM15->EGR |= TIM_EGR_UG;							// Update TIM1 Registers
	TIM15->DIER |= TIM_DIER_UIE;					// Update interrupt enable
	
	TIM15->CR1 |= TIM_CR1_OPM;						// TIM15 - One Pulse mode Enabled
	
	NVIC_EnableIRQ (TIM1_UP_TIM16_IRQn);	// NVIC IRQ Enable for TIM1
	//NVIC_EnableIRQ (TIM15_IRQn);					// NVIC IRQ Enable for TIM15
	
/* ************ EXTI Configuration ********* */	
	
	
	
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN; // Enable clock for EXTI IRQ	
	EXTI->IMR |= EXTI_IMR_MR6;						// Mask for button on PB6
	EXTI->IMR |= EXTI_IMR_MR7;						// Mask for button on PB7
	EXTI->IMR |= EXTI_IMR_MR10;						// Mask for button on PC10
	EXTI->IMR |= EXTI_IMR_MR11;						// Mask for button on PC11
	EXTI->IMR |= EXTI_IMR_MR12;						// Mask for button on PC12
	
	EXTI->FTSR |= 0x1CC0;				// Falling trigger EN for EXTI 6,7,10,11,12
	
	SYSCFG->EXTICR[1] |= SYSCFG_EXTICR2_EXTI6_PB;		// Exti line 6 set on PORTB
	SYSCFG->EXTICR[1] |= SYSCFG_EXTICR2_EXTI7_PB;		// Exti line 7 set on PORTB
	SYSCFG->EXTICR[2] |= SYSCFG_EXTICR3_EXTI10_PC;	// Exti line 10 set on PORTC
	SYSCFG->EXTICR[2] |= SYSCFG_EXTICR3_EXTI11_PC;	// Exti line 11 set on PORTC
  SYSCFG->EXTICR[3] |= SYSCFG_EXTICR4_EXTI12_PC;	// Exti line 12 set on PORTC
	

	
/* ************ DAC Configuration ********* */

	DAC->CR |= DAC_CR_EN1;								// DAC1 output Enable
	DAC->CR |= DAC_CR_BOFF1;							// DAC1 buffer enable
	
	GPIOC->BSRRL |= GPIO_BSRR_BS_3;				// Onboard red LED - ON
	DisplayStart(); 											// Initialization of LCD
	WaitMsg();	

	simpleDelay(7000000);
	
	
  TIM1->CR1 |= TIM_CR1_CEN;							// Timer 1 Counter enable
	
	
	
	DAC->DHR12R1 = 0xE8B;
	
GPIOC->BSRRH |= GPIO_BSRR_BS_3;				// Onboard red LED - off	


  EnteringMenu();
	NVIC_EnableIRQ(EXTI9_5_IRQn);				//Enable IRQ for PB6 PB7
	NVIC_EnableIRQ(EXTI15_10_IRQn);		  //Enable IRQ for PC10 PC11 PC12
	
	
/* Infinity loop */
while (1)
{

	
	
	
}

}



void EXTI9_5_IRQHandler(void) 								// Buttons PB6 PB7 IRQ
{
	unsigned int EXBUF = EXTI->PR;	// Mirror EXTI_PR Register to Exbuf
	
	EXTI->PR |= 0xC0;	 //Clear Pending bits: EXTI_PR_PR6 & EXTI_PR_PR7
	
	
	if (EXBUF & (1<<7)) // PB7 BUTTON PRESSED
	{
	 GPIOC->BSRRL |= GPIO_BSRR_BS_3;				// Onboard red LED - ON
	}
	
	if (EXBUF & (1<<6)) // PB6 BUTTON PRESSED
	{
	 GPIOA->BSRRL |= GPIO_BSRR_BS_8;				// Onboard red LED - ON
	}
	
	
	
	EXBUF	= 0x0;
}	

void EXTI15_10_IRQHandler(void) 							// Buttons PC10 PC11 PC12 IRQ
{
	
	unsigned int EXBUF = EXTI->PR;	// Mirror EXTI_PR Register to Exbuf
	EXTI->PR |= 0x1C00;	 //Clear Pending bits: EXTI_PR_PR10 / EXTI_PR_PR11 / EXTI_PR_PR12
	
	
	if (EXBUF & (1<<10)) // PC10 BUTTON PRESSED
	{
		EnergoEngInfo();
	GPIOC->BSRRH |= GPIO_BSRR_BS_3;				// Onboard red LED - Off
	}
	
	
	
	EXBUF	= 0x0;
}

