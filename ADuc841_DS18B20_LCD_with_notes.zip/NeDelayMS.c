﻿void NeDelayMS(unsigned int NoWorkTime) 
{
    /* Функция выжидания заданного времени (в мс) без выполнения операций */
	
	unsigned long int FFFFtime = (65535*1000 /(Fin/1)); // время в мс за период 0хFFFF
	unsigned long int THTLtime = 65535 - (65535*NoWorkTime/FFFFtime);
	unsigned char HighReg = THTLtime >> 8;
	unsigned char LowReg = (THTLtime - (HighReg * 0x100));
	
	TH0 = HighReg;
	TL0 = LowReg;
	
	TR0 = 1;
	
	while (TF0==0)
	{
	
	}
	
	TR0 = 0;	
	TF0 = 0;
	

}


  // По осциллографу получается 482,8 мкс (вместе с вызовом функции_!!!!!!


 //  65536-(65536*(MKS/5926)) тиков таймера